﻿// =============================================
// bluemoon.wtf — cart.js
// =============================================

const CART_KEY = 'bluemoon_cart';
const COUPON_KEY = 'bluemoon_applied_coupon';

function formatUsd(amount) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(amount) || 0);
}

const PRODUCT_IMAGES = {};

// ===== CART STATE =====
function getCart() {
    try {
        return JSON.parse(localStorage.getItem(CART_KEY)) || [];
    } catch {
        return [];
    }
}

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function addToCart(productId, productName, variant, variantName, price, imageUrl = '', variantId = '') {
    const cart = getCart();
    const existingIdx = cart.findIndex(item => item.productId === productId && item.variant === variant);

    if (existingIdx > -1) {
        cart[existingIdx].quantity = (cart[existingIdx].quantity || 1) + 1;
    } else {
        cart.push({
            productId,
            productName,
            variant,
            variantId: variantId || variant,
            variantName,
            price: parseFloat(price),
            imageUrl,
            quantity: 1
        });
    }

    saveCart(cart);
    updateCartBadge();
    openCart();
    renderCart();
}

function removeFromCart(productId, variant) {
    const cart = getCart().filter(item => !(item.productId === productId && item.variant === variant));
    saveCart(cart);
    updateCartBadge();
    renderCart();
}

function updateQuantity(productId, variant, delta) {
    const cart = getCart();
    const idx = cart.findIndex(item => item.productId === productId && item.variant === variant);
    if (idx === -1) return;
    cart[idx].quantity = Math.max(1, (cart[idx].quantity || 1) + delta);
    saveCart(cart);
    updateCartBadge();
    renderCart();
}

function clearCart() {
    saveCart([]);
    saveAppliedCoupon(null);
    updateCartBadge();
    renderCart();
}

window.clearbluemoonCart = clearCart;

// ===== BADGE =====
function updateCartBadge() {
    const cart = getCart();
    const total = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
    const badge = document.getElementById('cart-badge');
    if (!badge) return;
    if (total > 0) {
        badge.textContent = total;
        badge.style.display = 'flex';
    } else {
        badge.style.display = 'none';
    }
}

// ===== MODAL =====
function openCart() {
    const modal = document.getElementById('cart-modal');
    if (modal) modal.classList.add('active');
    renderCart();
}

function closeCart() {
    const modal = document.getElementById('cart-modal');
    if (modal) modal.classList.remove('active');
}

// ===== RENDER =====
function renderCart() {
    const cart = getCart();
    const cartItems = document.getElementById('cart-items');
    const cartEmpty = document.getElementById('cart-empty');
    const cartContent = document.getElementById('cart-content');
    const cartTotal = document.getElementById('cart-total');

    if (!cartItems) return;

    if (cart.length === 0) {
        if (cartEmpty) cartEmpty.style.display = 'flex';
        if (cartContent) cartContent.style.display = 'none';
        return;
    }

    if (cartEmpty) cartEmpty.style.display = 'none';
    if (cartContent) cartContent.style.display = 'flex';

    let total = 0;
    cartItems.innerHTML = cart.map(item => {
        const itemTotal = (item.price * (item.quantity || 1));
        total += itemTotal;
        const imgSrc = item.imageUrl || PRODUCT_IMAGES[item.productId] || '';

        // Sanitize for HTML display
        const safeProductName = escapeHtml(item.productName);
        const safeVariantName = escapeHtml(item.variantName);
        const safeProductId = escapeHtml(item.productId);
        const safeVariant = escapeHtml(item.variant);

        return `
        <div class="cart-item">
            ${imgSrc ? `<img src="${escapeAttr(imgSrc)}" alt="${safeProductName}" class="cart-item-thumb" onerror="this.style.display='none'">` : ''}
            <div class="cart-item-info">
                <div class="cart-item-name">${safeProductName}</div>
                <div class="cart-item-variant">${safeVariantName}</div>
                <div class="cart-item-price">${formatUsd(itemTotal)}</div>
            </div>
            <div class="cart-item-controls">
                <div class="cart-quantity-controls">
                    <button class="cart-quantity-btn cart-qty-minus" data-product-id="${safeProductId}" data-variant="${safeVariant}">−</button>
                    <span class="cart-quantity">${item.quantity || 1}</span>
                    <button class="cart-quantity-btn cart-qty-plus" data-product-id="${safeProductId}" data-variant="${safeVariant}">+</button>
                </div>
                <button class="cart-remove-btn" data-product-id="${safeProductId}" data-variant="${safeVariant}" title="Remove">
                    <span class="material-symbols-outlined">delete</span>
                </button>
            </div>
        </div>`;
    }).join('');

    if (cartTotal) cartTotal.textContent = formatUsd(total);

    // Coupon display
    const coupon = getAppliedCoupon();
    const discountRow = document.getElementById('cart-discount-row');
    const discountEl = document.getElementById('cart-discount');
    const couponMsg = document.getElementById('cart-coupon-msg');
    const couponInput = document.getElementById('cart-coupon-input');

    if (coupon) {
        const discount = calculateDiscount(total, coupon);
        if (discountRow) discountRow.style.display = discount > 0 ? 'flex' : 'none';
        if (discountEl) discountEl.textContent = '-' + formatUsd(discount);
        if (cartTotal) cartTotal.textContent = formatUsd(Math.max(0, total - discount));
        if (couponMsg) {
            const label = coupon.discount_type === 'percentage'
                ? `${Number(coupon.discount_value)}% off`
                : `${formatUsd(coupon.discount_value)} off`;
            couponMsg.innerHTML = `<span class="cart-coupon-applied"><code>${escapeHtml(coupon.code)}</code> — ${label} <button class="cart-coupon-remove" id="remove-coupon">✕</button></span>`;
            couponMsg.className = 'cart-coupon-msg cart-coupon-success';
        }
        if (couponInput) couponInput.style.display = 'none';
        const applyBtn = document.getElementById('cart-apply-coupon');
        if (applyBtn) applyBtn.style.display = 'none';
    } else {
        if (discountRow) discountRow.style.display = 'none';
        if (couponMsg) { couponMsg.innerHTML = ''; couponMsg.className = 'cart-coupon-msg'; }
        if (couponInput) couponInput.style.display = '';
        const applyBtn = document.getElementById('cart-apply-coupon');
        if (applyBtn) applyBtn.style.display = '';
    }

    // Bind remove buttons
    cartItems.querySelectorAll('.cart-remove-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            removeFromCart(btn.dataset.productId, btn.dataset.variant);
        });
    });

    // Bind quantity buttons
    cartItems.querySelectorAll('.cart-qty-minus').forEach(btn => {
        btn.addEventListener('click', () => {
            updateQuantity(btn.dataset.productId, btn.dataset.variant, -1);
        });
    });
    cartItems.querySelectorAll('.cart-qty-plus').forEach(btn => {
        btn.addEventListener('click', () => {
            updateQuantity(btn.dataset.productId, btn.dataset.variant, 1);
        });
    });
}

// Helpers to prevent XSS
function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function escapeAttr(str) {
    return escapeHtml(str);
}

// ===== COUPON STATE =====
function getAppliedCoupon() {
    try {
        return JSON.parse(localStorage.getItem(COUPON_KEY)) || null;
    } catch {
        return null;
    }
}

function saveAppliedCoupon(coupon) {
    if (coupon) {
        localStorage.setItem(COUPON_KEY, JSON.stringify(coupon));
    } else {
        localStorage.removeItem(COUPON_KEY);
    }
}

function calculateDiscount(subtotal, coupon) {
    if (!coupon) return 0;
    if (subtotal < Number(coupon.min_order_amount || 0)) return 0;
    if (coupon.discount_type === 'percentage') {
        return Math.min(subtotal, subtotal * (Number(coupon.discount_value) / 100));
    }
    return Math.min(subtotal, Number(coupon.discount_value));
}

async function applyCoupon() {
    const input = document.getElementById('cart-coupon-input');
    const msg = document.getElementById('cart-coupon-msg');
    if (!input || !msg) return;

    const code = input.value.trim().toUpperCase();
    if (!code) {
        msg.textContent = 'Enter a coupon code.';
        msg.className = 'cart-coupon-msg cart-coupon-error';
        return;
    }

    const supabaseUrl = window.bluemoon_SUPABASE_URL;
    const anonKey = window.bluemoon_SUPABASE_ANON_KEY;
    if (!supabaseUrl || !anonKey) {
        msg.textContent = 'Store configuration error.';
        msg.className = 'cart-coupon-msg cart-coupon-error';
        return;
    }

    msg.textContent = 'Checking...';
    msg.className = 'cart-coupon-msg';

    try {
        const res = await fetch(
            `${supabaseUrl}/rest/v1/coupons?code=eq.${encodeURIComponent(code)}&is_active=eq.true&select=id,code,discount_type,discount_value,min_order_amount,max_uses,times_used,expires_at`,
            {
                headers: {
                    'apikey': anonKey,
                    'Authorization': `Bearer ${anonKey}`
                }
            }
        );
        const data = await res.json();
        if (!Array.isArray(data) || !data.length) {
            msg.textContent = 'Invalid coupon code.';
            msg.className = 'cart-coupon-msg cart-coupon-error';
            return;
        }

        const coupon = data[0];

        if (coupon.expires_at && new Date(coupon.expires_at) < new Date()) {
            msg.textContent = 'This coupon has expired.';
            msg.className = 'cart-coupon-msg cart-coupon-error';
            return;
        }

        if (coupon.max_uses && coupon.times_used >= coupon.max_uses) {
            msg.textContent = 'This coupon has reached its usage limit.';
            msg.className = 'cart-coupon-msg cart-coupon-error';
            return;
        }

        const cart = getCart();
        const subtotal = cart.reduce((sum, item) => sum + (item.price * (item.quantity || 1)), 0);
        if (subtotal < Number(coupon.min_order_amount || 0)) {
            msg.textContent = `Minimum order of ${formatUsd(coupon.min_order_amount)} required.`;
            msg.className = 'cart-coupon-msg cart-coupon-error';
            return;
        }

        saveAppliedCoupon(coupon);
        msg.textContent = '';
        msg.className = 'cart-coupon-msg';
        input.value = '';
        renderCart();
    } catch {
        msg.textContent = 'Failed to validate coupon.';
        msg.className = 'cart-coupon-msg cart-coupon-error';
    }
}

function removeCoupon() {
    saveAppliedCoupon(null);
    renderCart();
}

// ===== CHECKOUT MODAL =====
function createCheckoutModal() {
    if (document.getElementById('checkout-modal')) return;
    const modal = document.createElement('div');
    modal.id = 'checkout-modal';
    modal.className = 'checkout-modal';
    modal.innerHTML = `
        <div class="checkout-modal-overlay" id="checkout-modal-overlay"></div>
        <div class="checkout-modal-dialog">
            <div class="checkout-modal-header">
                <h2 class="checkout-modal-title">Complete Your Order</h2>
                <button class="checkout-modal-close" id="checkout-modal-close">&times;</button>
            </div>
            <div class="checkout-modal-body">
                <div class="checkout-field">
                    <label class="checkout-label">Email Address <span class="checkout-required">*</span></label>
                    <input type="email" id="checkout-email" class="checkout-input" placeholder="your@email.com" autocomplete="email">
                    <span class="checkout-hint">We'll send your order confirmation here</span>
                </div>
                <div class="checkout-field">
                    <label class="checkout-label">Discord Username <span class="checkout-required">*</span></label>
                    <input type="text" id="checkout-discord" class="checkout-input" placeholder="username or username#1234" autocomplete="off">
                    <span class="checkout-hint">Your Discord username (for support and product access)</span>
                </div>
                <div class="checkout-field">
                    <label class="checkout-label">Payment Method <span class="checkout-required">*</span></label>
                    <div class="checkout-payment-options">
                        <div class="checkout-payment-option selected" data-method="stripe">
                            <span class="checkout-payment-icon">💳</span>
                            <span class="checkout-payment-label">Credit / Debit Card</span>
                        </div>
                        <div class="checkout-payment-option" data-method="crypto">
                            <span class="checkout-payment-icon">₿</span>
                            <span class="checkout-payment-label">Crypto (LTC, ETH, BTC, SOL)</span>
                        </div>
                        <div class="checkout-payment-option" data-method="paypal">
                            <span class="checkout-payment-icon"><i class="fab fa-paypal" style="color:#00457C;font-size:1.1rem;"></i></span>
                            <span class="checkout-payment-label">PayPal</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="checkout-modal-footer">
                <button class="checkout-btn-cancel" id="checkout-cancel">CANCEL</button>
                <button class="checkout-btn-proceed" id="checkout-proceed">PROCEED TO PAYMENT</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);

    // Payment option selection
    modal.querySelectorAll('.checkout-payment-option').forEach(opt => {
        opt.addEventListener('click', () => {
            modal.querySelectorAll('.checkout-payment-option').forEach(o => o.classList.remove('selected'));
            opt.classList.add('selected');
        });
    });

    // Close handlers
    document.getElementById('checkout-modal-overlay').addEventListener('click', closeCheckoutModal);
    document.getElementById('checkout-modal-close').addEventListener('click', closeCheckoutModal);
    document.getElementById('checkout-cancel').addEventListener('click', closeCheckoutModal);
    document.getElementById('checkout-proceed').addEventListener('click', proceedCheckout);
}

function openCheckoutModal() {
    createCheckoutModal();
    const modal = document.getElementById('checkout-modal');
    if (modal) modal.classList.add('active');
}

function closeCheckoutModal() {
    const modal = document.getElementById('checkout-modal');
    if (modal) modal.classList.remove('active');
}

async function proceedCheckout() {
    const email = document.getElementById('checkout-email')?.value.trim();
    const discord = document.getElementById('checkout-discord')?.value.trim();
    const selectedMethod = document.querySelector('.checkout-payment-option.selected')?.dataset.method || 'stripe';

    if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    const cart = getCart();
    if (cart.length === 0) return;
    const coupon = getAppliedCoupon();

    if (selectedMethod === 'stripe') {
        try {
            const response = await fetch('/api/create-checkout-session', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    items: cart.map(item => ({
                        productId: item.productId,
                        variantId: item.variantId || item.variant || '',
                        quantity: item.quantity || 1
                    })),
                    couponCode: coupon ? coupon.code : null,
                    customerEmail: email,
                    customerDiscord: discord
                })
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || 'Checkout failed');
            if (result.url) { window.location.href = result.url; return; }
            throw new Error('Missing checkout URL');
        } catch (error) {
            alert(error.message || 'Failed to start checkout');
        }
    } else {
        // Manual order (crypto or paypal)
        const isPaypal = selectedMethod === 'paypal';
        const paymentMethod = isPaypal ? 'paypal' : 'crypto';
        const isCrypto = selectedMethod === 'crypto';
        try {
            const response = await fetch('/api/manual-order', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    items: cart.map(item => ({
                        productId: item.productId,
                        variantId: item.variantId || item.variant || '',
                        quantity: item.quantity || 1
                    })),
                    couponCode: coupon ? coupon.code : null,
                    paymentMethod: paymentMethod,
                    customerEmail: email,
                    customerDiscord: discord
                })
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || 'Order failed');

            closeCheckoutModal();
            clearCart();
            closeCart();

            if (isPaypal) {
                showPaypalPaymentInfo(result.orderId);
            } else {
                showCryptoPaymentInfo(result.orderId);
            }
        } catch (error) {
            alert(error.message || 'Failed to submit order');
        }
    }
}

const CRYPTO_ADDRESSES = {
    crypto_ltc: { label: 'Litecoin (LTC)', addr: 'LXkn6dB4YvTu1FUqNshQVt8Ka2MUVg9Yeh' },
    crypto_eth: { label: 'Ethereum (ETH)', addr: '0x2156d1b4F5Db171145f7C2199414d79A0d73585D' },
    crypto_btc: { label: 'Bitcoin (BTC)', addr: 'bc1qvt6ewtnwkykkjmg4hamle2u48zy7jgaxvvpdyq' },
    crypto_sol: { label: 'Solana (SOL)', addr: 'Hksp8jzMfkKLkP8KEGx6C1fJvSpPXAEQzXrq8YoUekX5' }
};

function copyAddr(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
        const prev = btn.textContent;
        btn.textContent = 'Copied!';
        setTimeout(() => { btn.textContent = prev; }, 2000);
    }).catch(() => {
        window.prompt('Copy this address:', text);
    });
}

function showCryptoPaymentInfo(orderId) {
    // Build address rows for all coins
    const order = Object.keys(CRYPTO_ADDRESSES);
    const addrHtml = order.map(key => {
        const c = CRYPTO_ADDRESSES[key];
        const highlight = '';
        return `
            <div class="crypto-pay-address${highlight}">
                <span class="checkout-label">${c.label}</span>
                <div class="crypto-addr-row">
                    <code class="crypto-addr-display">${c.addr}</code>
                    <button type="button" class="crypto-copy-btn" data-addr="${c.addr}">Copy</button>
                </div>
            </div>`;
    }).join('');

    const infoModal = document.createElement('div');
    infoModal.className = 'checkout-modal active';
    infoModal.innerHTML = `
        <div class="checkout-modal-overlay"></div>
        <div class="checkout-modal-dialog checkout-modal-dialog--wide">
            <div class="checkout-modal-header">
                <h2 class="checkout-modal-title">Send Crypto Payment</h2>
            </div>
            <div class="checkout-modal-body">
                <div class="checkout-order-id-box">
                    <span class="checkout-label">Your Order ID</span>
                    <div class="crypto-addr-row">
                        <code class="order-id-display">${escapeHtml(orderId)}</code>
                        <button type="button" class="crypto-copy-btn" data-addr="${escapeHtml(orderId)}">Copy</button>
                    </div>
                </div>

                <div class="checkout-instructions">
                    <p><strong>How to pay:</strong></p>
                    <ol>
                        <li>Use the converter below to check the current USD → crypto rate.</li>
                        <li>Send the <strong>exact amount</strong> to the wallet address of your chosen coin.</li>
                        <li>Join our <a href="https://discord.gg/bluemoon" target="_blank" rel="noopener">Discord server</a> and open a <strong>support ticket</strong>.</li>
                        <li>Paste your <strong>Order ID</strong> and <strong>transaction hash / screenshot</strong> in the ticket to verify your payment.</li>
                        <li>Our team will confirm payment and deliver your product.</li>
                    </ol>
                </div>

                ${addrHtml}

                <div style="margin-top:16px;">
                    <a href="https://coinmarketcap.com/converter/" target="_blank" rel="noopener" class="checkout-converter-link">🔗 Live USD → Crypto Converter (CoinMarketCap)</a>
                </div>
            </div>
            <div class="checkout-modal-footer checkout-modal-footer--center">
                <a href="https://discord.gg/bluemoon" target="_blank" rel="noopener" class="checkout-btn-proceed"><i class="fab fa-discord"></i> Open Discord</a>
                <button class="checkout-btn-cancel checkout-info-close">CLOSE</button>
            </div>
        </div>
    `;
    document.body.appendChild(infoModal);

    // Copy buttons
    infoModal.querySelectorAll('.crypto-copy-btn').forEach(btn => {
        btn.addEventListener('click', () => copyAddr(btn.dataset.addr, btn));
    });
    infoModal.querySelector('.checkout-modal-overlay').addEventListener('click', () => infoModal.remove());
    infoModal.querySelector('.checkout-info-close').addEventListener('click', () => infoModal.remove());
}

function showPaypalPaymentInfo(orderId) {
    const paypalAddr = 'tubywam@spoko.pl';
    const infoModal = document.createElement('div');
    infoModal.className = 'checkout-modal active';
    infoModal.innerHTML = `
        <div class="checkout-modal-overlay"></div>
        <div class="checkout-modal-dialog checkout-modal-dialog--wide">
            <div class="checkout-modal-header">
                <h2 class="checkout-modal-title">Send PayPal Payment</h2>
            </div>
            <div class="checkout-modal-body">
                <div class="checkout-order-id-box">
                    <span class="checkout-label">Your Order ID</span>
                    <div class="crypto-addr-row">
                        <code class="order-id-display">${escapeHtml(orderId)}</code>
                        <button type="button" class="crypto-copy-btn" data-addr="${escapeHtml(orderId)}">Copy</button>
                    </div>
                </div>

                <div class="checkout-instructions">
                    <p><strong>How to pay:</strong></p>
                    <ol>
                        <li>Send the <strong>exact order amount</strong> (in USD) to the PayPal address below using <strong>Friends & Family</strong>.</li>
                        <li>Join our <a href="https://discord.gg/bluemoon" target="_blank" rel="noopener">Discord server</a> and open a <strong>support ticket</strong>.</li>
                        <li>Paste your <strong>Order ID</strong> and <strong>PayPal payment screenshot</strong> in the ticket to verify your payment.</li>
                        <li>Our team will confirm payment and deliver your product.</li>
                    </ol>
                </div>

                <div class="crypto-pay-address crypto-addr-highlight">
                    <span class="checkout-label">PayPal Address</span>
                    <div class="crypto-addr-row">
                        <code class="crypto-addr-display">${paypalAddr}</code>
                        <button type="button" class="crypto-copy-btn" data-addr="${paypalAddr}">Copy</button>
                    </div>
                </div>
            </div>
            <div class="checkout-modal-footer checkout-modal-footer--center">
                <a href="https://discord.gg/bluemoon" target="_blank" rel="noopener" class="checkout-btn-proceed"><i class="fab fa-discord"></i> Open Discord</a>
                <button class="checkout-btn-cancel checkout-info-close">CLOSE</button>
            </div>
        </div>
    `;
    document.body.appendChild(infoModal);

    infoModal.querySelectorAll('.crypto-copy-btn').forEach(btn => {
        btn.addEventListener('click', () => copyAddr(btn.dataset.addr, btn));
    });
    infoModal.querySelector('.checkout-modal-overlay').addEventListener('click', () => infoModal.remove());
    infoModal.querySelector('.checkout-info-close').addEventListener('click', () => infoModal.remove());
}

// ===== CHECKOUT =====
async function handleCheckout() {
    const cart = getCart();
    if (cart.length === 0) return;
    openCheckoutModal();
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    updateCartBadge();

    // Cart icon
    const cartIcon = document.getElementById('cart-icon');
    if (cartIcon) cartIcon.addEventListener('click', openCart);

    // Close button
    const closeBtn = document.getElementById('close-cart');
    if (closeBtn) closeBtn.addEventListener('click', closeCart);

    // Overlay click
    const overlay = document.getElementById('cart-overlay');
    if (overlay) overlay.addEventListener('click', closeCart);

    const checkoutBtn = document.getElementById('cart-checkout');
    if (checkoutBtn) checkoutBtn.addEventListener('click', handleCheckout);

    // Coupon apply button
    const applyBtn = document.getElementById('cart-apply-coupon');
    if (applyBtn) applyBtn.addEventListener('click', applyCoupon);

    // Coupon input enter key
    const couponInput = document.getElementById('cart-coupon-input');
    if (couponInput) couponInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); applyCoupon(); }
    });

    // Coupon remove (delegated)
    document.addEventListener('click', (e) => {
        if (e.target.id === 'remove-coupon' || e.target.closest('#remove-coupon')) {
            removeCoupon();
        }
    });

    // Add to cart buttons on product pages
    const addToCartBtn = document.getElementById('add-to-cart-btn');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', () => {
            const { productId, productName, variant, variantName, price } = addToCartBtn.dataset;
            addToCart(productId, productName, variant, variantName, price);
        });
    }

    renderCart();
});
