// =============================================
// bluemoon.wtf - Dynamic catalog rendering
// =============================================

(function () {
    let cachedSnapshot = null;

    function escapeHtml(value) {
        return String(value || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/\"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }

    function slugify(value) {
        return String(value || "")
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9\s-]/g, "")
            .replace(/\s+/g, "-")
            .replace(/-+/g, "-");
    }

    function formatCurrency(value) {
        return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(value || 0));
    }

    function getLowestVariantPrice(variants) {
        if (!variants || !variants.length) return null;
        return Math.min(...variants.map(v => Number(v.price || 0)));
    }

    async function loadSnapshot() {
        if (cachedSnapshot) return cachedSnapshot;

        const client = typeof window.getbluemoonSupabaseClient === "function"
            ? window.getbluemoonSupabaseClient()
            : null;

        if (!client) {
            cachedSnapshot = { categories: [], products: [], isFallback: true };
            return cachedSnapshot;
        }

        const categoriesResult = await client
            .from("categories")
            .select("id,name,slug,description,thumbnail_url,sort_order,is_active")
            .eq("is_active", true)
            .order("sort_order", { ascending: true })
            .order("name", { ascending: true });

        if (categoriesResult.error) {
            console.error("Failed to load categories", categoriesResult.error);
            cachedSnapshot = { categories: [], products: [], isFallback: true };
            return cachedSnapshot;
        }

        const categories = categoriesResult.data || [];
        const categoryMap = new Map(categories.map(c => [c.id, c]));

        const productsResult = await client
            .from("products")
            .select("id,name,slug,short_description,full_description,thumbnail_url,status,is_active,sort_order,category_id")
            .eq("is_active", true)
            .order("sort_order", { ascending: true })
            .order("name", { ascending: true });

        if (productsResult.error) {
            console.error("Failed to load products", productsResult.error);
            cachedSnapshot = { categories, products: [], isFallback: true };
            return cachedSnapshot;
        }

        const rawProducts = productsResult.data || [];

        const variantsResult = await client
            .from("product_variants")
            .select("id,product_id,name,price,compare_at_price,sort_order,is_default,is_active")
            .eq("is_active", true)
            .order("sort_order", { ascending: true })
            .order("name", { ascending: true });

        const variants = variantsResult.error ? [] : (variantsResult.data || []);
        const variantsByProduct = new Map();
        variants.forEach(variant => {
            if (!variantsByProduct.has(variant.product_id)) {
                variantsByProduct.set(variant.product_id, []);
            }
            variantsByProduct.get(variant.product_id).push(variant);
        });

        const products = rawProducts.map(product => {
            const category = categoryMap.get(product.category_id);
            const productVariants = variantsByProduct.get(product.id) || [];
            const minPrice = getLowestVariantPrice(productVariants);

            return {
                ...product,
                variants: productVariants,
                min_price: minPrice,
                has_variants: productVariants.length > 0,
                category_slug: category ? category.slug : "uncategorized",
                category_name: category ? category.name : "Uncategorized"
            };
        });

        cachedSnapshot = { categories, products, isFallback: false };
        return cachedSnapshot;
    }

    function getCategoryThumbnail(category, products) {
        if (category.thumbnail_url) return category.thumbnail_url;
        const withThumb = products.find(p => p.category_slug === category.slug && p.thumbnail_url);
        return withThumb ? withThumb.thumbnail_url : "assets/logo.png";
    }

    function countProducts(products, categorySlug) {
        return products.filter(p => p.category_slug === categorySlug).length;
    }

    async function renderHomeCategories() {
        const grid = document.getElementById("home-categories-grid");
        if (!grid) return;

        const snapshot = await loadSnapshot();
        const categories = snapshot.categories || [];
        const products = snapshot.products || [];

        if (!categories.length) {
            grid.innerHTML = "<p class=\"catalog-empty\">No categories yet. Create one from /admin.</p>";
            return;
        }

        grid.innerHTML = categories.map(category => {
            const thumbnail = getCategoryThumbnail(category, products);
            const productCount = countProducts(products, category.slug);
            return `
                <a href="/products?category=${encodeURIComponent(category.slug)}" class="category-card fade-in visible">
                    <img src="${escapeHtml(thumbnail)}" alt="${escapeHtml(category.name)}">
                </a>
            `;
        }).join("");
    }

    function getInitialCategoryFromQuery() {
        const params = new URLSearchParams(window.location.search);
        const category = params.get("category");
        return category ? slugify(category) : "all";
    }

    function updateCategoryInQuery(value) {
        const url = new URL(window.location.href);
        if (!value || value === "all") {
            url.searchParams.delete("category");
        } else {
            url.searchParams.set("category", value);
        }
        window.history.replaceState({}, "", url.toString());
    }

    function attachCardHandlers(container) {
        container.querySelectorAll(".product-variant-select").forEach(select => {
            select.addEventListener("change", () => {
                const option = select.selectedOptions[0];
                const card = select.closest(".product-card");
                if (!option || !card) return;

                const addBtn = card.querySelector(".add-product-btn");
                const priceEl = card.querySelector(".product-card-price");
                if (!addBtn || !priceEl) return;

                const price = Number(option.dataset.price || 0);
                addBtn.dataset.variantId = option.value;
                addBtn.dataset.variantName = option.dataset.variantName || option.textContent.trim();
                addBtn.dataset.price = String(price);
                priceEl.innerHTML = `<strong>${formatCurrency(price)}</strong>`;
            });
        });

        container.querySelectorAll(".add-product-btn").forEach(button => {
            button.addEventListener("click", () => {
                if (typeof window.addToCart !== "function") return;

                const productId = button.dataset.productId;
                const productName = button.dataset.productName;
                const variantId = button.dataset.variantId || "default";
                const variantName = button.dataset.variantName || "Standard";
                const price = Number(button.dataset.price || 0);
                const imageUrl = button.dataset.imageUrl || "";

                window.addToCart(productId, productName, variantId, variantName, price, imageUrl, variantId);
            });
        });
    }

    function renderProductsGrid(products, selectedCategory) {
        const grid = document.getElementById("products-grid");
        const featuredSection = document.getElementById("featured-products-section");
        const gridSection = document.getElementById("products-grid-section");
        if (!grid) return;

        const isAll = selectedCategory === "all";

        // Toggle featured vs grid sections
        if (featuredSection) featuredSection.style.display = isAll ? "block" : "none";
        if (gridSection) gridSection.style.display = isAll ? "none" : "block";

        if (isAll) return; // Featured grid handles "All" view

        const filteredProducts = products.filter(product => product.category_slug === selectedCategory);

        // Update grid header
        const gridTitle = document.getElementById("products-grid-title");
        const gridSubtitle = document.getElementById("products-grid-subtitle");
        const cat = filteredProducts[0];
        if (gridTitle) gridTitle.textContent = cat ? cat.category_name : selectedCategory;
        if (gridSubtitle) gridSubtitle.textContent = filteredProducts.length + " product" + (filteredProducts.length === 1 ? "" : "s") + " available";

        if (!filteredProducts.length) {
            grid.innerHTML = "<p class=\"catalog-empty\">No products in this category yet.</p>";
            return;
        }

        grid.innerHTML = filteredProducts.map(product => {
            const statusLabel = product.status ? escapeHtml(product.status) : "Available";
            const variants = product.variants || [];
            const defaultVariant = variants.find(v => v.is_default) || variants[0] || null;
            const priceLabel = product.has_variants
                ? "From " + formatCurrency(product.min_price || 0)
                : formatCurrency(defaultVariant ? defaultVariant.price : 0);

            return `
                <div class="product-card-page fade-in visible" data-category="${escapeHtml(product.category_slug)}">
                    <a href="/product/${encodeURIComponent(product.slug)}" class="product-img-page-link">
                        <div class="product-img-page">
                            <img src="${escapeHtml(product.thumbnail_url || "assets/logo.png")}" alt="${escapeHtml(product.name)}" class="product-image-page">
                            <div class="product-badges">
                                <span class="badge-product${statusLabel.toLowerCase() === 'active' ? ' badge-active' : ''}">${statusLabel}</span>
                            </div>
                        </div>
                    </a>
                    <div class="product-info-page">
                        <span class="product-category">${escapeHtml(product.category_name || "PRODUCTS")}</span>
                        <h3 class="product-title-page">${escapeHtml(product.name)}</h3>
                        <p class="product-description-page">${escapeHtml(product.short_description || "")}</p>
                        <div class="product-meta-page">
                            <div class="product-price-page">
                                <span class="price-main">${priceLabel}</span>
                            </div>
                            <a href="/product/${encodeURIComponent(product.slug)}" class="buy-btn-page">Buy Now</a>
                        </div>
                    </div>
                </div>
            `;
        }).join("");
    }

    function renderFeaturedGrid(categories, products) {
        const grid = document.getElementById("featured-products-grid");
        if (!grid) return;

        if (!categories.length) {
            grid.innerHTML = "<p class=\"catalog-empty\">No categories yet. Create one from /admin.</p>";
            return;
        }

        grid.innerHTML = categories.map(category => {
            const thumbnail = getCategoryThumbnail(category, products);
            return `
                <a href="#" class="featured-product-card fade-in visible" data-filter-trigger="${escapeHtml(category.slug)}">
                    <img src="${escapeHtml(thumbnail)}" alt="${escapeHtml(category.name)}" class="featured-product-image">
                </a>
            `;
        }).join("");

        // Wire featured card clicks to trigger filter
        grid.querySelectorAll("[data-filter-trigger]").forEach(card => {
            card.addEventListener("click", function (e) {
                e.preventDefault();
                const filter = card.dataset.filterTrigger;
                updateCategoryInQuery(filter);
                renderFilterButtons(categories, filter, products);
                renderProductsGrid(products, filter);
            });
        });
    }

    function renderFilterButtons(categories, selectedCategory, products) {
        const filterContainer = document.getElementById("filter-buttons");
        if (!filterContainer) return;

        const buttons = [
            `<div class="filter-all-wrapper"><button class="filter-btn ${selectedCategory === "all" ? "active" : ""}" data-filter="all"><i class="fas fa-grid-2"></i> All Products</button></div>`
        ];

        const categoryBtns = categories.map(category => {
            const count = products.filter(product => product.category_slug === category.slug).length;
            return `<button class="filter-btn ${selectedCategory === category.slug ? "active" : ""}" data-filter="${escapeHtml(category.slug)}">${escapeHtml(category.name)} (${count})</button>`;
        });

        if (categoryBtns.length) {
            buttons.push(`<div class="filter-games-wrapper">${categoryBtns.join("")}</div>`);
        }

        filterContainer.innerHTML = buttons.join("");

        filterContainer.querySelectorAll(".filter-btn").forEach(button => {
            button.addEventListener("click", () => {
                const filter = button.dataset.filter || "all";
                updateCategoryInQuery(filter);
                renderFilterButtons(categories, filter, products);
                renderProductsGrid(products, filter);
            });
        });
    }

    async function renderProductsPage() {
        const productsGrid = document.getElementById("products-grid");
        if (!productsGrid) return;

        const snapshot = await loadSnapshot();
        const categories = snapshot.categories || [];
        const products = snapshot.products || [];

        let selectedCategory = getInitialCategoryFromQuery();
        if (selectedCategory !== "all" && !categories.some(c => c.slug === selectedCategory)) {
            selectedCategory = "all";
        }

        renderFeaturedGrid(categories, products);
        renderFilterButtons(categories, selectedCategory, products);
        renderProductsGrid(products, selectedCategory);

        const heroDescription = document.getElementById("products-hero-description");
        if (heroDescription && snapshot.isFallback) {
            heroDescription.textContent = "Supabase client is not configured yet. Add credentials in supabase-config.js.";
        }
    }

    document.addEventListener("DOMContentLoaded", async () => {
        await renderHomeCategories();
        await renderProductsPage();
    });
})();
