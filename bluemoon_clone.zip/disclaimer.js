(function () {
    if (localStorage.getItem("bluemoon_tos_accepted")) return;

    var el = document.createElement("div");
    el.id = "tos-wrap";
    el.innerHTML = `
        <div class="tos-bg"></div>
        <div class="tos-box">
            <div class="tos-top">
                <span class="tos-tag">TERMS OF SERVICE</span>
                <h2>Legal Disclaimer</h2>
            </div>
            <div class="tos-scroll">
                <div class="tos-block">
                    <h4>1. Educational &amp; Research Purposes Only</h4>
                    <p>The software provided on this website is developed and distributed solely for educational, analytical, and research purposes within the field of system security and reverse engineering. The developer (the "Author") provides these tools to demonstrate system vulnerabilities and kernel-level interactions.</p>
                </div>
                <div class="tos-block">
                    <h4>2. User Responsibility</h4>
                    <p>By downloading, purchasing, or using any software from this platform, you (the "User") acknowledge that you are acting on your own volition. You understand that using third-party software to modify system memory or hardware identifiers may violate the Terms of Service of third-party platforms or games. The Author is <b>not</b> responsible for any account terminations, hardware bans, or data loss resulting from the use of this software.</p>
                </div>
                <div class="tos-block">
                    <h4>3. No Warranties &amp; "As-Is"</h4>
                    <p>This software is provided "AS IS" without any express or implied warranties. The Author does not guarantee that the software will be undetected by any third-party anti-cheat systems. Security software is constantly evolving, and what is functional today may be identified tomorrow.</p>
                </div>
                <div class="tos-block">
                    <h4>4. Non-Affiliation</h4>
                    <p>The Author is not affiliated, associated, authorized, endorsed by, or in any way officially connected with any game development companies (e.g., Ubisoft, Activision, Electronic Arts, Epic Games) or any of their subsidiaries or affiliates.</p>
                </div>
                <div class="tos-block">
                    <h4>5. Final Sale &amp; No Refunds</h4>
                    <p>Due to the digital nature of the products, all sales are final. By completing a purchase, you waive your right to a refund. Any attempt to initiate a chargeback will result in a permanent ban from our services and a report to the respective payment processors.</p>
                </div>
                <div class="tos-block">
                    <h4>6. Intellectual Property</h4>
                    <p>Reverse engineering, cracking, or redistributing this software without the Author's explicit consent is strictly prohibited and will result in a permanent termination of your license.</p>
                </div>
                <div class="tos-block">
                    <h4>7. Compliance</h4>
                    <p>We do not host any copyrighted game files. Our software interacts only with the operating system environment.</p>
                </div>
            </div>
            <div class="tos-bottom">
                <label class="tos-check">
                    <input type="checkbox" id="tos-cb">
                    <span class="tos-tick"></span>
                    I agree to the Terms of Service
                </label>
                <button id="tos-btn" disabled>Continue</button>
            </div>
        </div>
    `;

    var s = document.createElement("style");
    s.textContent = `
        #tos-wrap{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;padding:16px;animation:_tosIn .3s ease}
        @keyframes _tosIn{from{opacity:0}to{opacity:1}}
        @keyframes _tosOut{from{opacity:1}to{opacity:0}}
        .tos-bg{position:absolute;inset:0;background:rgba(0,0,0,.55);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}
        .tos-box{
            position:relative;width:100%;max-width:480px;max-height:85vh;
            display:flex;flex-direction:column;
            background:rgba(8,5,5,.92);
            border:1px solid rgba(255,255,255,.06);
            border-radius:14px;
            box-shadow:0 20px 60px rgba(0,0,0,.5),0 0 0 1px rgba(255,26,26,.06);
            animation:_tosBoxIn .4s cubic-bezier(.2,.8,.2,1);
        }
        @keyframes _tosBoxIn{from{opacity:0;transform:translateY(16px) scale(.97)}to{opacity:1;transform:none}}
        .tos-top{padding:22px 24px 14px;border-bottom:1px solid rgba(255,255,255,.04)}
        .tos-tag{
            display:inline-block;font-size:.65rem;font-weight:700;letter-spacing:1.5px;
            color:#ff1a1a;text-transform:uppercase;margin-bottom:8px;
        }
        .tos-top h2{margin:0;font-size:1.05rem;font-weight:700;color:#fff;font-family:'Inter',sans-serif}
        .tos-scroll{
            flex:1;overflow-y:auto;padding:16px 24px;
            scrollbar-width:thin;scrollbar-color:rgba(255,26,26,.15) transparent;
        }
        .tos-scroll::-webkit-scrollbar{width:3px}
        .tos-scroll::-webkit-scrollbar-track{background:transparent}
        .tos-scroll::-webkit-scrollbar-thumb{background:rgba(255,26,26,.2);border-radius:10px}
        .tos-block{margin-bottom:14px}
        .tos-block:last-child{margin-bottom:0}
        .tos-block h4{
            margin:0 0 4px;font-size:.78rem;font-weight:600;color:rgba(255,255,255,.7);
            font-family:'Inter',sans-serif;
        }
        .tos-block p{
            margin:0;font-size:.76rem;line-height:1.6;color:rgba(255,255,255,.35);
            font-family:'Inter',sans-serif;
        }
        .tos-block b{color:#ff1a1a;font-weight:600}
        .tos-bottom{
            padding:14px 24px 18px;border-top:1px solid rgba(255,255,255,.04);
            display:flex;flex-direction:column;gap:12px;
        }
        .tos-check{
            display:flex;align-items:center;gap:10px;cursor:pointer;
            font-size:.78rem;color:rgba(255,255,255,.45);font-family:'Inter',sans-serif;
            user-select:none;transition:color .15s;
        }
        .tos-check:hover{color:rgba(255,255,255,.7)}
        .tos-check input{display:none}
        .tos-tick{
            width:16px;height:16px;flex-shrink:0;border-radius:4px;
            border:1.5px solid rgba(255,255,255,.12);transition:all .2s;
            display:flex;align-items:center;justify-content:center;
        }
        .tos-tick::after{
            content:'';width:4px;height:7px;
            border:solid #fff;border-width:0 2px 2px 0;
            transform:rotate(45deg) scale(0);transition:transform .15s;margin-top:-1px;
        }
        .tos-check input:checked~.tos-tick{background:#ff1a1a;border-color:#ff1a1a}
        .tos-check input:checked~.tos-tick::after{transform:rotate(45deg) scale(1)}
        #tos-btn{
            width:100%;padding:10px;font-family:'Inter',sans-serif;
            font-size:.8rem;font-weight:600;color:#fff;
            background:#ff1a1a;border:none;border-radius:8px;
            cursor:pointer;transition:all .2s;letter-spacing:.3px;
        }
        #tos-btn:disabled{opacity:.25;cursor:not-allowed}
        #tos-btn:not(:disabled):hover{background:#e61616;box-shadow:0 0 20px rgba(255,26,26,.25)}
        @media(max-width:500px){
            .tos-box{max-width:100%;border-radius:12px}
            .tos-top{padding:18px 18px 12px}
            .tos-scroll{padding:14px 18px}
            .tos-bottom{padding:12px 18px 16px}
        }
    `;

    document.head.appendChild(s);
    document.body.appendChild(el);
    document.body.style.overflow = "hidden";

    var cb = document.getElementById("tos-cb");
    var btn = document.getElementById("tos-btn");

    cb.addEventListener("change", function () { btn.disabled = !cb.checked; });

    btn.addEventListener("click", function () {
        if (!cb.checked) return;
        localStorage.setItem("bluemoon_tos_accepted", Date.now());
        el.style.animation = "_tosOut .25s ease forwards";
        el.addEventListener("animationend", function () {
            el.remove(); s.remove();
            document.body.style.overflow = "";
        });
    });
})();
