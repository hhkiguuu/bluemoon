// =============================================
// bluemoon.wtf — script.js
// =============================================

// ===== HEXAGON CANVAS BACKGROUND =====
(function () {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let width, height, hexagons = [];
    const HEX_SIZE = 32;
    const HEX_GAP = 4;
    let mouseX = -9999, mouseY = -9999;

    function resize() {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
        buildGrid();
    }

    function hexWidth() { return Math.sqrt(3) * (HEX_SIZE + HEX_GAP); }
    function hexHeight() { return 2 * (HEX_SIZE + HEX_GAP); }

    function buildGrid() {
        hexagons = [];
        const hw = hexWidth();
        const hh = hexHeight() * 0.75;
        const cols = Math.ceil(width / hw) + 2;
        const rows = Math.ceil(height / hh) + 2;

        for (let r = -1; r < rows; r++) {
            for (let c = -1; c < cols; c++) {
                const x = c * hw + (r % 2 === 0 ? 0 : hw / 2);
                const y = r * hh;
                hexagons.push({ x, y, opacity: Math.random() * 0.06 + 0.02, baseOpacity: Math.random() * 0.06 + 0.02, phase: Math.random() * Math.PI * 2 });
            }
        }
    }

    function drawHex(x, y, size, opacity) {
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
            const angle = Math.PI / 180 * (60 * i - 30);
            const px = x + size * Math.cos(angle);
            const py = y + size * Math.sin(angle);
            if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.strokeStyle = `rgba(255, 26, 26, ${opacity})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
        ctx.fillStyle = `rgba(255, 26, 26, ${opacity * 0.12})`;
        ctx.fill();
    }

    let frame = 0;
    function animate() {
        ctx.clearRect(0, 0, width, height);
        frame++;

        hexagons.forEach(hex => {
            const dist = Math.hypot(hex.x - mouseX, hex.y - mouseY);
            const glow = dist < 180 ? (1 - dist / 180) * 0.35 : 0;
            const pulse = hex.baseOpacity + Math.sin(frame * 0.012 + hex.phase) * 0.015;
            hex.opacity += (pulse + glow - hex.opacity) * 0.05;
            drawHex(hex.x, hex.y, HEX_SIZE, Math.max(0, hex.opacity));
        });

        requestAnimationFrame(animate);
    }

    window.addEventListener('resize', resize);
    document.addEventListener('mousemove', e => { mouseX = e.clientX; mouseY = e.clientY; });

    resize();
    animate();
})();


// ===== CUSTOM CURSOR =====
(function () {
    const cursor = document.getElementById('cursor');
    const cursorBlur = document.getElementById('cursor-blur');
    if (!cursor || !cursorBlur) return;

    // Hide by default until we know the setting
    cursor.style.display = 'none';
    cursorBlur.style.display = 'none';

    // Fetch cursor setting from Supabase
    const sbUrl = window.bluemoon_SUPABASE_URL || 'https://xwkpkgmgksgxnvpmibaq.supabase.co';
    const sbKey = window.bluemoon_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3a3BrZ21na3NneG52cG1pYmFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ4MDA3MTEsImV4cCI6MjA5MDM3NjcxMX0.gkQWZnliq2xQuCu42eI-X6tiq-1V4puf9Dg1bJw3roU';

    fetch(`${sbUrl}/rest/v1/site_settings?key=eq.custom_cursor_enabled&select=value`, {
        headers: { 'apikey': sbKey, 'Authorization': `Bearer ${sbKey}` }
    })
    .then(r => r.json())
    .then(rows => {
        const enabled = !rows.length || rows[0].value !== 'false';
        if (!enabled) return;

        cursor.style.display = '';
        cursorBlur.style.display = '';
        document.documentElement.classList.add('custom-cursor');

        let cx = 0, cy = 0, bx = 0, by = 0;
        document.addEventListener('mousemove', e => { cx = e.clientX; cy = e.clientY; });

        function updateCursor() {
            cursor.style.transform = `translate(${cx - 6}px, ${cy - 6}px)`;
            bx += (cx - bx) * 0.08;
            by += (cy - by) * 0.08;
            cursorBlur.style.transform = `translate(${bx - 24}px, ${by - 24}px)`;
            requestAnimationFrame(updateCursor);
        }
        updateCursor();

        const hoverSelector = 'a, button, .product-variant, .filter-btn, .faq-header, .icon-btn, .category-card';

        document.addEventListener('mouseover', e => {
            if (e.target.closest(hoverSelector)) cursor.classList.add('cursor-hover');
        });

        document.addEventListener('mouseout', e => {
            if (e.target.closest(hoverSelector)) cursor.classList.remove('cursor-hover');
        });
    })
    .catch(() => {
        // On error, show cursor as fallback
        cursor.style.display = '';
        cursorBlur.style.display = '';
        document.documentElement.classList.add('custom-cursor');
    });
})();


// ===== NAVBAR SCROLL BEHAVIOR =====
(function () {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;
    let lastY = 0;
    window.addEventListener('scroll', () => {
        const y = window.scrollY;
        if (y > 60) {
            navbar.classList.add('scrolled');
            navbar.classList.toggle('navbar-hidden', y > lastY + 10 && y > 160);
            navbar.classList.remove('navbar-hidden');
        } else {
            navbar.classList.remove('scrolled');
        }
        lastY = y;
    });
})();


// ===== HAMBURGER MOBILE MENU =====
(function () {
    const btn = document.getElementById('hamburger-menu');
    const menu = document.getElementById('mobile-menu');
    if (!btn || !menu) return;

    btn.addEventListener('click', () => {
        const open = menu.classList.toggle('open');
        btn.classList.toggle('active', open);
        document.body.style.overflow = open ? 'hidden' : '';
    });

    document.addEventListener('click', e => {
        if (!menu.contains(e.target) && !btn.contains(e.target)) {
            menu.classList.remove('open');
            btn.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    menu.querySelectorAll('.mobile-menu-link').forEach(link => {
        link.addEventListener('click', () => {
            menu.classList.remove('open');
            btn.classList.remove('active');
            document.body.style.overflow = '';
        });
    });
})();


// ===== FAQ ACCORDION =====
(function () {
    document.querySelectorAll('.faq-header').forEach(header => {
        header.addEventListener('click', () => {
            const item = header.closest('.faq-item');
            const answer = item.querySelector('.faq-answer');
            const icon = header.querySelector('.toggle-icon');
            const isOpen = item.classList.contains('open');

            // Close all
            document.querySelectorAll('.faq-item.open').forEach(openItem => {
                openItem.classList.remove('open');
                openItem.querySelector('.faq-answer').style.maxHeight = null;
                openItem.querySelector('.toggle-icon').textContent = '+';
            });

            if (!isOpen) {
                item.classList.add('open');
                answer.style.maxHeight = answer.scrollHeight + 'px';
                icon.textContent = '−';
            }
        });
    });
})();


// ===== PRODUCT TABS =====
(function () {
    document.querySelectorAll('.product-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.dataset.tab;
            const panel = btn.closest('.product-tabs');
            panel.querySelectorAll('.product-tab-btn').forEach(b => b.classList.remove('active'));
            panel.querySelectorAll('.product-tab-content').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            const target = document.getElementById('tab-' + tabId);
            if (target) target.classList.add('active');
        });
    });
})();


// ===== FADE-IN INTERSECTION OBSERVER =====
(function () {
    const fadeEls = document.querySelectorAll('.fade-in');
    if (!fadeEls.length) return;

    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    fadeEls.forEach(el => {
        if (!el.classList.contains('visible')) observer.observe(el);
    });
})();
