// =============================================
// bluemoon.wtf - Supabase client configuration
// =============================================

window.bluemoon_SUPABASE_URL = "https://xwkpkgmgksgxnvpmibaq.supabase.co";
window.bluemoon_SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3a3BrZ21na3NneG52cG1pYmFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ4MDA3MTEsImV4cCI6MjA5MDM3NjcxMX0.gkQWZnliq2xQuCu42eI-X6tiq-1V4puf9Dg1bJw3roU";
window.bluemoon_STRIPE_PUBLISHABLE_KEY = "pk_test_51Sy95b3pO7AKUCkiJiNQ5EAd7Hi82hCypdCKM4hl1Oh2A2vGQcWbqa9ancrw5twrqxjKY9VTCAuDAogXKG5n7KOP00Mlzq9a8j";

window.getbluemoonSupabaseClient = function getbluemoonSupabaseClient() {
    if (!window.supabase || typeof window.supabase.createClient !== "function") {
        return null;
    }

    const url = window.bluemoon_SUPABASE_URL;
    const key = window.bluemoon_SUPABASE_ANON_KEY;

    if (!url || !key) {
        return null;
    }

    if (!window.__bluemoonSupabaseClient) {
        window.__bluemoonSupabaseClient = window.supabase.createClient(url, key, {
            auth: {
                persistSession: true,
                autoRefreshToken: true,
                storageKey: 'bluemoon-auth',
                detectSessionInUrl: false,
                flowType: 'implicit'
            }
        });
    }

    return window.__bluemoonSupabaseClient;
};
